import { prisma } from "../src/lib/db";
import { buildSiteBrief } from "../src/lib/domain/brief";
import { replyToAgent, publicShare } from "../src/lib/services/sites";

async function main() {
  const owner = await prisma.membership.findFirst({ where: { role: "OWNER" } });
  const project = await prisma.siteProject.findFirst({ where: { name: { contains: "Автосервис" } }, include: { organization: { include: { contacts: true } } } });
  if (!owner || !project) throw new Error("no project");
  const org = project.organization;
  const phones = org.contacts.filter((item) => item.type === "phone").map((item) => item.value);
  const emails = org.contacts.filter((item) => item.type === "email").map((item) => item.value);
  const socials = org.contacts.filter((item) => item.type === "social").map((item) => item.value);
  const brief = buildSiteBrief(
    {
      name: org.name,
      category: org.category,
      city: org.city,
      region: org.region,
      address: org.address,
      phones,
      emails,
      socials,
      website: org.website,
      websiteStatus: org.websiteStatus,
      rating: org.rating,
      reviewCount: org.reviewCount,
      services: org.services,
      features: org.features,
      hours: org.hours,
      description: org.description,
      sourceUrl: org.sourceUrl,
    },
    {
      siteType: "services",
      language: "ru",
      style: null,
      pages: ["Главная", "Направления", "Как проходит работа", "Контакты"],
      wishes: "Не меняй премиальный вид. Исправь только данные организации: они должны быть видны.",
    },
  );
  const order = [
    "Не перерисовывай дизайн. На странице контактов, в шапке и в подвале покажи данные этой организации.",
    `Телефон, кликабельный: ${phones.join(", ") || "нет"}.`,
    `Адрес: ${org.address || "нет"}.`,
    `ВКонтакте, отдельной ссылкой на точный адрес: ${socials.join(", ") || org.website || "нет"}.`,
    "Почты в карточке нет. Удали hello@example.ru и любой другой email, иконку почты и слова «пишите».",
    "Остальную премиальную вёрстку сохрани.",
    "",
    brief,
  ].join("\n");
  await replyToAgent(owner.tenantId, owner.userId, project.id, order);
  let confirmed = false;
  const started = Date.now();
  while (Date.now() - started < 480000) {
    await new Promise((resolve) => setTimeout(resolve, 10000));
    const current = await prisma.siteProject.findUnique({ where: { id: project.id } });
    console.log(current?.status);
    if (current?.status === "preview_ready" || current?.status === "failed") break;
    if (current?.status === "waiting_user" && !confirmed) {
      confirmed = true;
      await replyToAgent(owner.tenantId, owner.userId, project.id, "Вноси правку сразу, без плана. На странице /contacts/, в шапке и в подвале оставь телефон, адрес и ссылку ВКонтакте. Почту hello@example.ru удали полностью. Дизайн не перерисовывай.");
      console.log("confirmed");
    }
  }
  const ready = await prisma.siteProject.findUnique({ where: { id: project.id } });
  if (ready?.status !== "preview_ready") throw new Error(`still ${ready?.status}`);
  const shared = await publicShare(owner.tenantId, owner.userId, project.id);
  console.log("public", shared.url);
  await prisma.$disconnect();
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : "failed");
  process.exit(1);
});
